const TWEAKS = /*EDITMODE-BEGIN*/{
  "affiliateUrl": "#PLACEHOLDER_CTA",
  "skipAgeGate": true,
  "bonusAmount": 25,
  "wheelWinAmount": 150,
  "primaryCta": "CLAIM MY BONUS",
  "headlineLine1": "EARN ON",
  "headlineLine2": "EVERY SCROLL",
  "subheadline": "You already scroll for hours every day. Now get paid for it. Join thousands cashing out daily. Simple.",
  "accentHueA": 219,
  "accentHueB": 232,
  "showPayoutProof": true,
  "showOfferGrid": true,
  "urgencyBanner": true
}/*EDITMODE-END*/;

const accent = (h) => `oklch(0.72 0.19 ${h})`;
const accentSoft = (h) => `oklch(0.85 0.12 ${h})`;

function App() {
  const [tweaks, setTweaks] = React.useState(TWEAKS);
  const [tweaksOn, setTweaksOn] = React.useState(false);
  const [stage, setStage] = React.useState(tweaks.skipAgeGate ? 'main' : 'gate');

  React.useEffect(() => {
    const onMsg = (e) => {
      const d = e.data;
      if (!d || typeof d !== 'object') return;
      if (d.type === '__activate_edit_mode') setTweaksOn(true);
      if (d.type === '__deactivate_edit_mode') setTweaksOn(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const updateTweak = (k, v) => {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
  };

  return (
    <>
      <div className="stage">
        {stage === 'gate' && !tweaks.skipAgeGate
          ? <AgeGate onContinue={() => setStage('flash')} tweaks={tweaks}/>
          : stage === 'flash'
          ? <QualifiedFlash tweaks={tweaks} onDone={() => setStage('main')}/>
          : <Main tweaks={tweaks}/>}
      </div>
      {tweaksOn && <TweaksPanel tweaks={tweaks} update={updateTweak} onStageReset={() => setStage(tweaks.skipAgeGate ? 'main' : 'gate')}/>}
    </>
  );
}

// ───────── QUALIFIED FLASH ─────────
function QualifiedFlash({ tweaks, onDone }) {
  const a = tweaks.accentHueA, b = tweaks.accentHueB;
  React.useEffect(() => {
    const t = setTimeout(onDone, 1400);
    return () => clearTimeout(t);
  }, []);
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: `radial-gradient(ellipse at center, ${accent(a)}28 0%, #061320 60%, #03090F 100%)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexDirection: 'column', padding: 24, overflow: 'hidden',
      animation: 'qfFadeIn 0.2s ease-out',
    }}>
      {/* starburst rays */}
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.5, animation: 'qfSpin 6s linear infinite' }} viewBox="-100 -100 200 200" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="qfRay" x1="0" x2="1">
            <stop offset="0%" stopColor={accent(a)} stopOpacity="0"/>
            <stop offset="100%" stopColor={accent(a)} stopOpacity="0.6"/>
          </linearGradient>
        </defs>
        {Array.from({ length: 12 }).map((_, i) => (
          <rect key={i} x="0" y="-1.5" width="200" height="3" fill="url(#qfRay)" transform={`rotate(${i * 30})`}/>
        ))}
      </svg>

      {/* confetti */}
      {Array.from({ length: 28 }).map((_, i) => {
        const hue = i % 2 === 0 ? a : b;
        const left = (i * 37) % 100;
        const delay = (i % 10) * 0.03;
        const dur = 1.0 + ((i * 7) % 5) * 0.08;
        const rot = (i * 53) % 360;
        return (
          <span key={i} style={{
            position: 'absolute', top: '50%', left: `${left}%`,
            width: 8, height: 12, background: accent(hue),
            borderRadius: 2, boxShadow: `0 0 12px ${accent(hue)}`,
            animation: `qfConfetti ${dur}s cubic-bezier(.2,.6,.3,1) ${delay}s forwards`,
            transform: `rotate(${rot}deg)`,
          }}/>
        );
      })}

      {/* check badge */}
      <div style={{
        width: 96, height: 96, borderRadius: '50%',
        background: `linear-gradient(135deg, ${accent(a)}, ${accent(b)})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: `0 0 60px ${accent(a)}, 0 0 120px ${accent(a)}80`,
        animation: 'qfPop 0.5s cubic-bezier(.2,1.4,.4,1)',
        marginBottom: 22, position: 'relative', zIndex: 2,
      }}>
        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#061320" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12" style={{ strokeDasharray: 30, strokeDashoffset: 30, animation: 'qfCheck 0.4s ease-out 0.2s forwards' }}/>
        </svg>
      </div>

      <div style={{
        position: 'relative', zIndex: 2, textAlign: 'center',
        animation: 'qfSlideUp 0.4s cubic-bezier(.2,.8,.3,1) 0.1s backwards',
      }}>
        <div style={{
          fontSize: 11, letterSpacing: '0.22em', fontWeight: 800,
          color: accentSoft(b), marginBottom: 10,
        }}>
          ✨ CONGRATULATIONS ✨
        </div>
        <h1 style={{
          fontFamily: '"Inter Tight"', fontWeight: 900,
          fontSize: 36, lineHeight: 1, letterSpacing: '-0.04em',
          margin: '0 0 10px', color: '#fff',
        }}>
          YOU QUALIFIED<br/>
          FOR A <span style={{
            background: `linear-gradient(90deg, ${accentSoft(a)}, ${accentSoft(b)})`,
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>FREE SPIN</span>
        </h1>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <span style={{
            width: 14, height: 14, borderRadius: '50%',
            border: `2px solid ${accent(b)}`, borderTopColor: 'transparent',
            animation: 'qfSpin 0.8s linear infinite',
          }}/>
          Unlocking your offers…
        </div>
      </div>

      
    </div>
  );
}

// ───────── AGE GATE ─────────
function AgeGate({ onContinue, tweaks }) {
  const [picked, setPicked] = React.useState(null);
  const click = (v) => {
    setPicked(v);
    setTimeout(onContinue, 280);
  };
  const a = tweaks.accentHueA, b = tweaks.accentHueB;
  return (
    <div className="card" style={{
      position: 'relative', overflow: 'hidden',
      background: 'linear-gradient(180deg, #0A1626 0%, #061320 100%)',
      padding: '28px 22px 22px',
    }}>
      <div style={{ position: 'absolute', top: -40, right: -20, width: 180, height: 180, borderRadius: '50%',
        background: `radial-gradient(circle, ${accent(a)}40 0%, transparent 65%)`, pointerEvents: 'none' }}/>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
        <Logo a={a} b={b}/>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 5,
          fontSize: 10, fontWeight: 700,
          color: accentSoft(b),
          background: `color-mix(in oklch, ${accent(b)} 10%, transparent)`,
          padding: '5px 9px', borderRadius: 99,
          border: `1px solid color-mix(in oklch, ${accent(b)} 30%, transparent)`,
        }}>
          <IShield size={10} color={accent(b)}/>
          VERIFIED BUSINESS
        </div>
      </div>

      <div style={{
        width: 60, height: 60, borderRadius: 22,
        background: `linear-gradient(135deg, color-mix(in oklch, ${accent(a)} 25%, transparent), color-mix(in oklch, ${accent(b)} 15%, transparent))`,
        border: `1px solid color-mix(in oklch, ${accent(a)} 40%, transparent)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 18,
      }}>
        <IShield size={28} color={accentSoft(a)}/>
      </div>

      <h1 style={{
        fontFamily: '"Inter Tight"', fontWeight: 800,
        fontSize: 30, lineHeight: 1.05, letterSpacing: '-0.035em',
        margin: '0 0 8px',
      }}>How old are you?</h1>
      <p style={{ fontSize: 13.5, color: 'rgba(255,255,255,0.6)', lineHeight: 1.45, margin: '0 0 22px' }}>
        Select your age group to continue. This helps us show you the right offers and payouts.
      </p>

      <AgeCard
        selected={picked === 'over'}
        onClick={() => click('over')}
        accent={accent(b)}
        accentSoft={accentSoft(b)}
        icon={<ICheck size={20} color={accent(b)}/>}
        title="I'm 21 or Older"
        sub="Full access to all offers & payouts"
      />
      <div style={{ height: 10 }}/>
      <AgeCard
        selected={picked === 'under'}
        onClick={() => click('under')}
        accent="#86EFAC"
        accentSoft="#D1FAE5"
        icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#86EFAC" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>}
        title="I'm Under 21"
        sub="Limited offers & reduced payouts"
      />

      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', textAlign: 'center', margin: '18px 0 14px', lineHeight: 1.4 }}>
        By continuing, you confirm your age selection is accurate.
      </div>

      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        padding: '8px 12px',
        background: `color-mix(in oklch, ${accent(b)} 8%, transparent)`,
        border: `1px solid color-mix(in oklch, ${accent(b)} 18%, transparent)`,
        borderRadius: 99,
        fontSize: 11, color: accentSoft(b), fontWeight: 600,
        width: 'fit-content', margin: '0 auto',
      }}>
        <span style={{
          width: 6, height: 6, borderRadius: '50%', background: accent(b),
          boxShadow: `0 0 6px ${accent(b)}`, animation: 'fcPulse 1.4s ease-in-out infinite',
        }}/>
        New accounts approved daily
      </div>

      
    </div>
  );
}

function AgeCard({ selected, onClick, accent, accentSoft, icon, title, sub }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '15px 15px', width: '100%',
        background: selected ? `color-mix(in oklch, ${accent} 12%, rgba(255,255,255,0.03))` : 'rgba(255,255,255,0.03)',
        border: `1px solid ${selected ? accent : (hover ? `color-mix(in oklch, ${accent} 40%, transparent)` : 'rgba(255,255,255,0.08)')}`,
        borderRadius: 16, cursor: 'pointer', color: '#fff',
        transition: 'all 0.2s',
        transform: selected ? 'scale(0.98)' : 'scale(1)',
      }}>
      <div style={{
        width: 42, height: 42, borderRadius: 12,
        background: `color-mix(in oklch, ${accent} 15%, transparent)`,
        border: `1px solid color-mix(in oklch, ${accent} 35%, transparent)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>{icon}</div>
      <div style={{ flex: 1, textAlign: 'left' }}>
        <div style={{ fontFamily: '"Inter Tight"', fontWeight: 700, fontSize: 16, letterSpacing: '-0.02em', marginBottom: 2 }}>{title}</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)' }}>{sub}</div>
      </div>
      <div style={{ color: accent, fontSize: 20, fontWeight: 800, transition: 'transform 0.2s', transform: hover ? 'translateX(3px)' : 'none' }}>→</div>
    </button>
  );
}

function Logo({ a, b, size = 34 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <img src="gravypass-logo.png" width={size} height={size}
        style={{ borderRadius: size * 0.24, boxShadow: '0 4px 12px rgba(0,0,0,0.4), inset 0 0 0 1px rgba(255,255,255,0.08)', display: 'block' }}
        alt="GravyPass"/>
      <span style={{ fontFamily: '"Poppins", -apple-system, sans-serif', fontWeight: 700, fontSize: Math.round(size * 0.62), letterSpacing: '-0.02em', color: '#fff', lineHeight: 1 }}>gravypass</span>
    </div>
  );
}

// ───────── MAIN PAGE ─────────
function Main({ tweaks }) {
  const [earnings, setEarnings] = React.useState(58.21);
  const [live, setLive] = React.useState(4128);
  const [burstKey, setBurstKey] = React.useState(0);
  const [wheelWon, setWheelWon] = React.useState(false);
  const [spikePct, setSpikePct] = React.useState(null); // null => normal % ; once chart passes "3 offers", spikes exponentially
  const a = tweaks.accentHueA, b = tweaks.accentHueB;

  // (earnings graph removed — % indicator stays modest via the normal branch below)

  React.useEffect(() => {
    let timer;
    const tick = () => {
      setEarnings(e => {
        // drifts up overall but jitters up/down to look alive
        const delta = (Math.random() - 0.30) * 0.55;
        const next = Math.max(57.80, e + delta);
        return +next.toFixed(2);
      });
      setLive(u => Math.max(3800, u + Math.floor(Math.random() * 7 - 2)));
      timer = setTimeout(tick, 3000 + Math.random() * 2000); // every 3–5s
    };
    timer = setTimeout(tick, 3000 + Math.random() * 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="card" style={{
      position: 'relative', overflow: 'hidden',
      background: 'linear-gradient(180deg, #0A1626 0%, #061320 60%, #03090F 100%)',
      padding: '16px 18px 28px',
    }}>
      {/* ambient blobs */}
      <div style={{ position: 'absolute', top: -50, left: -40, width: 240, height: 240, borderRadius: '50%',
        background: `radial-gradient(circle, color-mix(in oklch, ${accent(a)} 35%, transparent) 0%, transparent 65%)`,
        pointerEvents: 'none', zIndex: 0 }}/>
      <div style={{ position: 'absolute', top: 140, right: -60, width: 220, height: 220, borderRadius: '50%',
        background: `radial-gradient(circle, color-mix(in oklch, ${accent(b)} 30%, transparent) 0%, transparent 65%)`,
        pointerEvents: 'none', zIndex: 0 }}/>

      <Confetti trigger={burstKey} count={45}/>

      <div style={{ position: 'relative', zIndex: 1, animation: 'riseIn 0.75s cubic-bezier(0.16,1,0.3,1) both' }}>
        {/* top bar */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <Logo a={a} b={b}/>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 6,
            fontSize: 10.5, color: accentSoft(a), fontWeight: 600, letterSpacing: '0.01em',
            background: `color-mix(in oklch, ${accent(a)} 12%, transparent)`,
            backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
            padding: '7px 13px', borderRadius: 99,
            border: `1px solid color-mix(in oklch, ${accent(a)} 24%, transparent)`,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: accent(a),
              boxShadow: `0 0 8px ${accent(a)}`, animation: 'fcPulse 1.2s ease-in-out infinite' }}/>
            {live.toLocaleString()} EARNING NOW
          </div>
        </div>

        {/* headline */}
        <h1 style={{
          fontFamily: '"Inter Tight"', fontWeight: 900,
          fontSize: 40, lineHeight: 0.96, letterSpacing: '-0.04em',
          textAlign: 'center', margin: '10px 0 12px',
        }}>
          <span style={{
            display: 'inline-block',
            background: 'linear-gradient(100deg, #fff 0%, #fff 43%, #CFF3FF 50%, #fff 57%, #fff 100%)',
            backgroundSize: '250% 100%',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            animation: 'headlineShine 13s linear infinite',
          }}>{tweaks.headlineLine1}</span><br/>
          <span style={{
            background: `linear-gradient(100deg, ${accentSoft(a)} 0%, ${accentSoft(a)} 40%, #FFFFFF 50%, ${accentSoft(b)} 60%, ${accentSoft(b)} 100%)`,
            backgroundSize: '250% 100%',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            fontSize: 'min(58px, 12.5vw)', display: 'inline-block', lineHeight: 0.95,
            filter: `drop-shadow(0 0 24px color-mix(in oklch, ${accent(a)} 42%, transparent))`,
            animation: 'headlineShine 13s linear infinite',
          }}>{tweaks.headlineLine2}</span>
        </h1>
        <p style={{ textAlign: 'center', fontSize: 13.5, color: 'rgba(255,255,255,0.65)', margin: '0 8px 12px', lineHeight: 1.45 }}>
          {tweaks.subheadline}
        </p>

        <TierLadder/>

        <ScrollEarnPill/>

        {/* trust strip removed */}

        {/* live earnings card removed */}

        {/* WHY COMPANIES PAY YOU — removed */}
        {false && (
        <div style={{
          marginTop: 14,
          padding: '12px 14px',
          background: `linear-gradient(135deg, color-mix(in oklch, ${accent(a)} 12%, transparent), rgba(255,255,255,0.025))`,
          border: `1px solid color-mix(in oklch, ${accent(a)} 28%, transparent)`,
          borderRadius: 14,
        }}>
          <div style={{ fontSize: 9.5, letterSpacing: '0.18em', fontWeight: 800, color: accentSoft(a), marginBottom: 4 }}>
            WHY COMPANIES PAY YOU
          </div>
          <div style={{ fontFamily: '"Inter Tight"', fontWeight: 800, fontSize: 14, lineHeight: 1.25, marginBottom: 4, letterSpacing: '-0.01em' }}>
            App developers spend{' '}
            <span style={{
              background: `linear-gradient(90deg, ${accentSoft(a)}, ${accentSoft(b)})`,
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>$83 billion/year</span>{' '}
            getting real users to try their apps.
          </div>
          <div style={{ fontSize: 11.5, color: 'rgba(255,255,255,0.65)', lineHeight: 1.4 }}>
            We cut out the agencies and pay that money straight to you. They get honest feedback. You get paid. That's the entire deal.
          </div>
        </div>
        )}

        {/* offer grid */}
        {false && tweaks.showOfferGrid && (
          <div style={{ marginTop: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ fontFamily: '"Inter Tight"', fontWeight: 800, fontSize: 17, letterSpacing: '-0.02em' }}>
                🔥 Top offers today
              </div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)' }}>Refreshed 2m ago</div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[
                ['Royal Match', 'Reach Lvl 5', '30.00', window.IMG.ROYAL],
                ['Coin Master', 'Spin 10 times', '15.00', window.IMG.COIN],
                ['Temu App', 'Install + browse', '23.50', window.IMG.TEMU],
                ['Survey Junkie', 'Finish 1 survey', '7.75', window.IMG.SURVEY],
              ].map(([name, task, amt, img], i) => (
                <div key={i} style={{
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: 12, padding: '11px 11px',
                }}>
                  <img src={img} alt={name}
                    width={36} height={36}
                    style={{
                      width: 36, height: 36, borderRadius: 9, marginBottom: 8, display: 'block',
                      objectFit: 'cover',
                      boxShadow: '0 6px 14px rgba(0,0,0,0.35), inset 0 0 0 1px rgba(255,255,255,0.12)',
                    }}/>
                  <div style={{ fontFamily: '"Inter Tight"', fontWeight: 700, fontSize: 12.5, marginBottom: 1 }}>{name}</div>
                  <div style={{ fontSize: 10.5, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>{task}</div>
                  <div style={{
                    display: 'inline-block',
                    fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 13,
                    background: `linear-gradient(90deg, ${accentSoft(a)}, ${accentSoft(b)})`,
                    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                  }}>+${amt}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* THREE STEPS TO CASH */}
        <div style={{
          marginTop: 30, marginBottom: 4,
          padding: '20px 16px 18px',
          background: 'rgba(255,255,255,0.025)',
          border: '1px solid rgba(255,255,255,0.08)',
          borderRadius: 22,
        }}>
          <div style={{ textAlign: 'center', marginBottom: 14 }}>
            <h3 style={{
              fontFamily: '"Inter Tight"', fontWeight: 900,
              fontSize: 24, lineHeight: 1.05, letterSpacing: '-0.035em',
              margin: 0,
            }}>3 steps to cash.</h3>
          </div>
          {[
            { n: 1, title: 'Add GravyPass to Apple Wallet', body: 'Free, straight into Apple Wallet. Adds in 30 seconds and your welcome bonus lands in your balance instantly.' },
            { n: 2, title: 'Play to earn', body: 'Play mobile games, mini-games, and offers. Each one pays out.' },
            { n: 3, title: 'Cash out anytime', body: 'PayPal, CashApp, or Venmo. No minimums.' },
          ].map(s => (
            <div key={s.n} style={{
              display: 'flex', gap: 12, alignItems: 'center',
              padding: '12px 14px',
              background: s.n === 1 ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.03)',
              border: s.n === 1 ? `1px solid color-mix(in oklch, ${accent(a)} 40%, transparent)` : '1px solid rgba(255,255,255,0.07)',
              borderRadius: 13,
              marginBottom: 8,
            }}>
              {s.n === 1 ? (
                <img src="gravypass-logo.png" alt="GravyPass" width={46} height={46} style={{
                  width: 46, height: 46, borderRadius: 12, flexShrink: 0, objectFit: 'cover',
                  boxShadow: '0 4px 14px rgba(0,0,0,0.45), inset 0 0 0 1px rgba(255,255,255,0.14)',
                }}/>
              ) : (
                <div style={{
                  width: 32, height: 32, borderRadius: 10,
                  background: `color-mix(in oklch, ${accent(a)} 20%, transparent)`,
                  border: `1px solid color-mix(in oklch, ${accent(a)} 45%, transparent)`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 15,
                  color: accentSoft(a), flexShrink: 0,
                }}>{s.n}</div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#fff', marginBottom: 2 }}>{s.title}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.6)', lineHeight: 1.4 }}>{s.body}</div>
                {s.n === 1 && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6, fontSize: 10.5, fontWeight: 700, color: 'rgba(255,255,255,0.5)' }}>
                    <span style={{ display: 'flex', gap: 1 }}>{[0,1,2,3,4].map(i => <IStar key={i} size={10} fill={accent(b)}/>)}</span>
                    <span style={{ color: '#fff' }}>4.8</span>
                    <span>· Wallet · Free · iOS</span>
                  </div>
                )}
              </div>
              {s.n === 1 && (
                <div onClick={(e) => { e.stopPropagation(); goToOffer(); }} style={{
                  flexShrink: 0, cursor: 'pointer',
                  fontSize: 12, fontWeight: 800, letterSpacing: '0.03em', color: '#fff',
                  background: `linear-gradient(180deg, ${accent(a)}, ${accent(b)})`,
                  padding: '7px 18px', borderRadius: 99,
                  boxShadow: `0 4px 14px color-mix(in oklch, ${accent(a)} 42%, transparent)`,
                }}>ADD</div>
              )}
            </div>
          ))}
          <div style={{ marginTop: 12 }}>
            <NeonButton a={a} b={b} onClick={() => goToOffer()}>
              Add To Apple Wallet
            </NeonButton>
          </div>
        </div>

        {/* LOCKED APPS GALLERY — unlock by adding the pass */}
        <div style={{
          marginTop: 30,
          background: `linear-gradient(135deg, color-mix(in oklch, ${accent(a)} 16%, transparent), color-mix(in oklch, ${accent(b)} 14%, transparent))`,
          border: `1px solid color-mix(in oklch, ${accent(a)} 38%, transparent)`,
          borderRadius: 22, padding: '16px 14px 18px',
          position: 'relative', overflow: 'hidden',
        }}>
          {/* pill */}

          <div style={{
            fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 16, lineHeight: 1.2,
            letterSpacing: '-0.01em', marginBottom: 16,
          }}>
            Get paid to play the games you{' '}
            <span style={{
              background: `linear-gradient(90deg, ${accentSoft(a)}, ${accentSoft(b)})`,
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>already love</span>
          </div>

          {/* rolling marquee */}
          <div style={{
            position: 'relative', margin: '0 -14px', overflow: 'hidden',
            WebkitMaskImage: 'linear-gradient(90deg, transparent, #000 7%, #000 93%, transparent)',
            maskImage: 'linear-gradient(90deg, transparent, #000 7%, #000 93%, transparent)',
          }}>
            <div style={{
              display: 'flex', width: 'max-content',
              willChange: 'transform', backfaceVisibility: 'hidden',
              animation: 'gravyRoll 26s linear infinite',
            }}>
              {(() => {
                const apps = [
                  { name: 'Subway Surfers', img: 'icons/subway.jpg' },
                  { name: 'Roblox',         img: 'icons/roblox.jpg' },
                  { name: 'Monopoly GO',    img: 'icons/monopoly.jpg' },
                  { name: 'Candy Crush',    img: 'icons/candy.jpg' },
                  { name: 'Royal Match',    img: 'icons/royalmatch.jpg' },
                  { name: 'Dice Dreams',    img: 'icons/dicedreams.jpg' },
                ];
                return [...apps, ...apps].map((app, i) => (
                  <div key={i} style={{ width: 72, marginRight: 16, flexShrink: 0, textAlign: 'center' }}>
                    <div style={{ position: 'relative', width: 72, height: 72, marginBottom: 6 }}>
                      <img src={app.img} alt={app.name} width={72} height={72} draggable={false} style={{
                        width: 72, height: 72, borderRadius: 16, display: 'block', objectFit: 'cover',
                        filter: 'grayscale(1) brightness(0.92) contrast(0.95)',
                        boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.1)',
                      }}/>
                      {/* lock overlay */}
                      <div style={{
                        position: 'absolute', inset: 0, borderRadius: 16,
                        background: 'rgba(8,10,16,0.34)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                          <rect x="5" y="11" width="14" height="9" rx="2" fill="rgba(255,255,255,0.94)"/>
                          <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="rgba(255,255,255,0.94)" strokeWidth="2" fill="none"/>
                          <circle cx="12" cy="15.5" r="1.4" fill="#0A0D14"/>
                        </svg>
                      </div>
                    </div>
                    <div style={{ fontSize: 9.5, fontWeight: 600, color: 'rgba(255,255,255,0.55)', lineHeight: 1.1, whiteSpace: 'nowrap' }}>
                      {app.name}
                    </div>
                  </div>
                ));
              })()}
            </div>
            {/* center unlock button */}
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}>
              <button onClick={() => goToOffer()} style={{
                pointerEvents: 'auto',
                display: 'inline-flex', alignItems: 'center', gap: 8,
                fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 14, letterSpacing: '0.03em',
                color: '#042033',
                background: 'linear-gradient(180deg, #54D8FC, #1E9FE0)',
                border: 'none', borderRadius: 99, padding: '11px 22px',
                cursor: 'pointer',
                boxShadow: '0 8px 24px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.35)',
              }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                  <rect x="5" y="11" width="14" height="9" rx="2" fill="#042033"/>
                  <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#042033" strokeWidth="2.4" fill="none"/>
                </svg>
                UNLOCK
              </button>
            </div>
          </div>
        </div>

        {/* final CTA */}
        <div style={{ marginTop: 30, textAlign: 'center' }}>
          <h2 style={{ fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 26, letterSpacing: '-0.035em', margin: '0 0 6px', lineHeight: 1.05 }}>
            Still playing for free?
          </h2>
          <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.65)', margin: '0 0 14px', lineHeight: 1.45 }}>
            Stop giving your time away. Add the pass to your wallet and claim your bonus instantly.
          </p>
          <div onClick={() => goToOffer()} style={{
            display: 'inline-block', cursor: 'pointer', lineHeight: 0,
            borderRadius: 11, overflow: 'hidden',
            boxShadow: `0 10px 30px rgba(0,0,0,0.55), 0 0 26px color-mix(in oklch, ${accent(a)} 26%, transparent)`,
          }}>
            <img src="apple-wallet-badge.png" alt="Add to Apple Wallet"
              width={220} height={68} style={{ display: 'block', width: 220, height: 'auto' }}/>
          </div>
        </div>

        <div style={{ fontSize: 9.5, color: 'rgba(255,255,255,0.32)', textAlign: 'center', marginTop: 16, lineHeight: 1.4 }}>
          18+ only. Rewards & payouts subject to T&Cs. Not affiliated with Apple, Google or any advertised brand. Brands shown are for illustrative purposes only and may not be available in the current offer pool.
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, marginTop: 10 }}>
          <a href="privacy.html" style={{ fontSize: 10.5, color: accentSoft(a), textDecoration: 'none', fontWeight: 600 }}>Privacy Policy</a>
          <span style={{ color: 'rgba(255,255,255,0.25)', fontSize: 10 }}>·</span>
          <a href="terms.html" style={{ fontSize: 10.5, color: accentSoft(a), textDecoration: 'none', fontWeight: 600 }}>Terms of Service</a>
        </div>
        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.28)', textAlign: 'center', marginTop: 8 }}>
          © 2026 · All rights reserved.
        </div>
        {/* clearance for the sticky CTA bar */}
        <div style={{ height: 'calc(150px + env(safe-area-inset-bottom))' }}/>
      </div>

      

      <StickyCta a={a} b={b}/>

    </div>
  );
}

// ----- RANK LADDER (Noob / Pro / God) -----
const TIERS = [
  {
    key: 'noob', name: 'NOOB', icon: 'egg',
    req: '0-2 offers complete',
    perk: 'General offer pool unlocked',
    shell: 'linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.018))',
    ring: '1px solid rgba(255,255,255,0.10)',
    badge: 'linear-gradient(150deg, #A2ABB3 0%, #737C83 52%, #545C62 100%)',
    badgeInk: '#0D1013', reqInk: 'rgba(255,255,255,0.52)',
  },
  {
    key: 'pro', name: 'PRO', icon: 'bolt',
    req: '2-5 offers complete',
    perk: 'Exclusive offer pool with higher payouts',
    shell: 'linear-gradient(135deg, rgba(147,51,234,0.16), rgba(88,28,135,0.07))',
    ring: '1px solid rgba(168,85,247,0.32)',
    badge: 'linear-gradient(150deg, #C084FC 0%, #A855F7 45%, #7C3AED 100%)',
    badgeInk: '#160726', reqInk: 'rgba(233,213,255,0.78)',
  },
  {
    key: 'god', name: 'SCROLLER', icon: 'star',
    req: '5+ offers',
    perk: 'Scroll testing mode + higher payouts with exclusive offers',
    shell: 'linear-gradient(135deg, rgba(255,196,84,0.17), rgba(146,90,10,0.07))',
    ring: '1px solid rgba(255,199,89,0.40)',
    badge: 'linear-gradient(150deg, #FFE9A8 0%, #FFC65C 42%, #E39A16 100%)',
    badgeInk: '#241300', reqInk: 'rgba(255,231,178,0.82)',
  },
];

function TierLadder() {
  return (
    <div style={{ margin: '2px 0 16px' }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 7, margin: '0 2px 8px',
        fontSize: 9.5, fontWeight: 800, letterSpacing: '0.16em',
        color: 'rgba(255,255,255,0.34)', textTransform: 'uppercase',
      }}>
        <span style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.14))' }}/>
        Rank progression
        <span style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, rgba(255,255,255,0.14), transparent)' }}/>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {TIERS.map((t, i) => (
          <div key={t.key} style={{
            position: 'relative',
            animation: 'tlRise 0.62s cubic-bezier(0.16,1,0.3,1) both',
            animationDelay: (0.06 + i * 0.09) + 's',
          }}>
            {t.key === 'god' && (
              <div aria-hidden="true" style={{
                position: 'absolute', inset: -7, borderRadius: 24, zIndex: 0, pointerEvents: 'none',
                background: 'radial-gradient(60% 120% at 18% 50%, rgba(255,201,92,0.55) 0%, rgba(255,170,40,0.20) 45%, transparent 78%)',
                filter: 'blur(11px)',
                animation: 'tlGodAura 2.6s ease-in-out infinite',
              }}/>
            )}

            <div style={Object.assign({
              position: 'relative', zIndex: 1, overflow: 'hidden',
              display: 'flex', alignItems: 'center', gap: 11,
              padding: '10px 13px 10px 10px', borderRadius: 17,
              background: t.shell, border: t.ring,
              backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)',
              boxShadow: t.key === 'god'
                ? '0 4px 24px rgba(226,150,20,0.26), inset 0 1px 0 rgba(255,255,255,0.14)'
                : 'inset 0 1px 0 rgba(255,255,255,0.06)',
            }, t.key === 'pro' ? { animation: 'tlProGlow 3s ease-in-out infinite' } : {})}>

              {t.key !== 'noob' && (
                <div aria-hidden="true" style={{
                  position: 'absolute', top: 0, bottom: 0, left: 0, width: '38%', zIndex: 2, pointerEvents: 'none',
                  background: t.key === 'god'
                    ? 'linear-gradient(90deg, transparent, rgba(255,236,190,0.30), transparent)'
                    : 'linear-gradient(90deg, transparent, rgba(233,213,255,0.24), transparent)',
                  animation: 'tlSheen ' + (t.key === 'god' ? '3.4s' : '4.2s') + ' ease-in-out infinite',
                  animationDelay: t.key === 'god' ? '0.5s' : '0s',
                }}/>
              )}

              <div style={{
                position: 'relative', zIndex: 3, flexShrink: 0,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
                minWidth: 74, padding: '7px 11px', borderRadius: 99,
                background: t.badge, color: t.badgeInk,
                fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 12.5, letterSpacing: '0.04em',
                boxShadow: t.key === 'god'
                  ? '0 3px 14px rgba(255,178,44,0.55), inset 0 1px 0 rgba(255,255,255,0.65)'
                  : t.key === 'pro'
                  ? '0 3px 14px rgba(147,51,234,0.5), inset 0 1px 0 rgba(255,255,255,0.4)'
                  : 'inset 0 1px 0 rgba(255,255,255,0.3)',
              }}>
                {t.icon === 'egg' && <IEgg size={11} color={t.badgeInk}/>}
                {t.icon === 'bolt' && <IBolt size={11} color={t.badgeInk}/>}
                {t.icon === 'star' && <IStar size={11} fill={t.badgeInk}/>}
                {t.name}
                {t.key === 'god' && (
                  <span aria-hidden="true" style={{
                    position: 'absolute', top: -2, right: -1, width: 5, height: 5, borderRadius: '50%',
                    background: '#FFF6DC', boxShadow: '0 0 8px 2px rgba(255,224,150,0.95)',
                    animation: 'tlSpark 2.2s ease-in-out infinite',
                  }}/>
                )}
              </div>

              <div style={{ position: 'relative', zIndex: 3, flex: 1, minWidth: 0, textAlign: 'right' }}>
                <div style={{
                  fontSize: 11.5, fontWeight: 700, color: t.reqInk,
                  letterSpacing: '-0.01em', lineHeight: 1.25,
                }}>{t.req}</div>
                <div style={Object.assign({
                  marginTop: 2.5, fontSize: 10.5, fontWeight: 600, lineHeight: 1.3,
                  letterSpacing: '-0.005em',
                }, t.key === 'god' ? {
                  background: 'linear-gradient(100deg, #E0A93C 0%, #F6C860 18%, #FFE9A8 32%, #FFFBEA 40%, #FFE9A8 48%, #F6C860 62%, #E0A93C 100%)',
                  backgroundSize: '200% 100%',
                  WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent',
                  filter: 'drop-shadow(0 0 6px rgba(255,199,89,0.32))',
                  animation: 'tlGoldFlow 3.4s ease-in-out 0.5s infinite',
                } : { color: '#5FC7E3' })}>{t.perk}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ----- SCROLL-TO-EARN DEMO PILL -----
const SE_REELS = [
  { bg: 'linear-gradient(165deg, #2B1B4D 0%, #101A3A 100%)', pfp: 'pfp/jerome.png',  handle: '@dailygrind',  tag: 'sponsored clip', likes: '48.2K', comments: '1,204', shares: '3.1K' },
  { bg: 'linear-gradient(165deg, #123B2C 0%, #07231C 100%)', pfp: 'pfp/jermony.png', handle: '@cashcuts',    tag: 'brand reel',     likes: '12.9K', comments: '486',   shares: '921' },
  { bg: 'linear-gradient(165deg, #4A2318 0%, #1E0F0A 100%)', pfp: 'pfp/jermone.png', handle: '@scrollpays',  tag: 'partner ad',     likes: '77.4K', comments: '2,880', shares: '6.4K' },
  { bg: 'linear-gradient(165deg, #17324F 0%, #0A1626 100%)', pfp: 'pfp/jerome.png',  handle: '@testerfeed',  tag: 'sponsored clip', likes: '9.8K',  comments: '312',   shares: '744' },
  { bg: 'linear-gradient(165deg, #3D1836 0%, #170A16 100%)', pfp: 'pfp/jermony.png', handle: '@payperview',  tag: 'brand reel',     likes: '31.5K', comments: '967',   shares: '2.2K' },
];

const SE_RATE = 0.25;
const SE_H = 172;   // reel viewport height
const SE_W = 104;   // reel viewport width

function ScrollEarnPill() {
  const [i, setI] = React.useState(0);
  const [bal, setBal] = React.useState(12.5);
  const [pops, setPops] = React.useState([]);
  const wrapRef = React.useRef(null);
  const [live, setLive] = React.useState(true);

  // pause the loop when the pill is scrolled out of view
  React.useEffect(() => {
    const el = wrapRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver(
      (es) => setLive(es[0].isIntersecting),
      { threshold: 0.25 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  React.useEffect(() => {
    if (!live) return;
    const t = setInterval(() => {
      setI((n) => n + 1);
      setBal((b) => (b > 90 ? 12.5 : +(b + SE_RATE).toFixed(2)));
      const id = 'p' + Math.random().toString(36).slice(2, 8);
      setPops((ps) => ps.concat([id]));
      setTimeout(() => setPops((ps) => ps.filter((x) => x !== id)), 1100);
    }, 1550);
    return () => clearInterval(t);
  }, [live]);

  const cards = [];
  for (let k = i - 1; k <= i + 2; k++) cards.push(k);

  return (
    <div ref={wrapRef} style={{
      position: 'relative', margin: '0 0 16px', padding: '11px 13px 13px',
      borderRadius: 20, overflow: 'hidden',
      background: 'linear-gradient(150deg, rgba(84,216,252,0.10) 0%, rgba(255,255,255,0.035) 45%, rgba(255,255,255,0.02) 100%)',
      border: '1px solid rgba(84,216,252,0.22)',
      backdropFilter: 'blur(14px)', WebkitBackdropFilter: 'blur(14px)',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.08), 0 6px 26px rgba(0,0,0,0.28)',
    }}>
      {/* ---- BALANCE BAR (top) ---- */}
      <div style={{
        position: 'relative', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
        paddingBottom: 10, marginBottom: 11,
        borderBottom: '1px solid rgba(255,255,255,0.08)',
      }}>
        <div>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 5,
            fontSize: 9, fontWeight: 800, letterSpacing: '0.14em',
            color: 'rgba(255,255,255,0.42)', textTransform: 'uppercase', marginBottom: 3,
          }}>
            <span style={{
              width: 5, height: 5, borderRadius: '50%', background: '#54D8FC',
              boxShadow: '0 0 8px #54D8FC', animation: 'fcPulse 1.2s ease-in-out infinite',
            }}/>
            Your balance
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span key={bal} style={{
              fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 27, lineHeight: 1,
              letterSpacing: '-0.03em', color: '#BAE6FD',
              textShadow: '0 0 18px rgba(84,216,252,0.5)',
              display: 'inline-block',
              animation: 'seBalPop 0.5s cubic-bezier(0.16,1,0.3,1)',
            }}>${bal.toFixed(2)}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: 'rgba(255,255,255,0.34)' }}>USD</span>
          </div>
        </div>

        {/* dedicated flight lane for the +$0.25 credits */}
        <div style={{ position: 'relative', flex: 1, alignSelf: 'stretch', minWidth: 44 }}>
          {pops.map((id) => (
            <span key={id} style={{
              position: 'absolute', left: '50%', bottom: 4,
              transform: 'translate(-50%, 0)', whiteSpace: 'nowrap',
              fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 15, letterSpacing: '-0.02em',
              color: '#54D8FC', textShadow: '0 0 14px rgba(84,216,252,0.75)',
              animation: 'seFly 1.1s cubic-bezier(0.16,1,0.3,1) forwards',
              pointerEvents: 'none',
            }}>+${SE_RATE.toFixed(2)}</span>
          ))}
        </div>

        <div style={{ textAlign: 'right', paddingBottom: 2 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: '5px 9px', borderRadius: 99,
            background: 'rgba(84,216,252,0.12)',
            border: '1px solid rgba(84,216,252,0.28)',
            fontSize: 9.5, fontWeight: 800, letterSpacing: '0.01em', color: '#BAE6FD',
          }}>
            <IBolt size={9} color="#BAE6FD"/>
            ${SE_RATE.toFixed(2)} / SCROLL
          </div>
        </div>
      </div>

      {/* ---- PHONE + COPY ---- */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
        {/* phone */}
        <div style={{
          position: 'relative', flexShrink: 0,
          width: SE_W + 8, height: SE_H + 8, padding: 4,
          borderRadius: 17, background: 'linear-gradient(160deg, #2A3646, #0D1622)',
          boxShadow: '0 8px 22px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.16)',
        }}>
          <div style={{
            position: 'relative', width: SE_W, height: SE_H,
            borderRadius: 13, overflow: 'hidden', background: '#060C12',
          }}>
            {cards.map((idx) => {
              const r = SE_REELS[((idx % SE_REELS.length) + SE_REELS.length) % SE_REELS.length];
              return (
                <div key={idx} style={{
                  position: 'absolute', left: 0, top: 0, width: SE_W, height: SE_H,
                  background: r.bg,
                  transform: 'translateY(' + ((idx - i) * SE_H) + 'px)',
                  transition: 'transform 0.62s cubic-bezier(0.22,1,0.28,1)',
                  willChange: 'transform',
                }}>
                  {/* soft light sweep so each reel reads as video, not a flat block */}
                  <div style={{
                    position: 'absolute', inset: 0,
                    background: 'radial-gradient(90% 60% at 30% 22%, rgba(255,255,255,0.16), transparent 70%)',
                  }}/>
                  {/* sponsored tag */}
                  <div style={{
                    position: 'absolute', top: 6, left: 6,
                    padding: '2px 5px', borderRadius: 5,
                    background: 'rgba(0,0,0,0.42)', backdropFilter: 'blur(4px)',
                    fontSize: 6.5, fontWeight: 800, letterSpacing: '0.06em',
                    color: 'rgba(255,255,255,0.82)', textTransform: 'uppercase',
                  }}>{r.tag}</div>
                  {/* right-rail social actions */}
                  <div style={{
                    position: 'absolute', right: 4, bottom: 40,
                    display: 'flex', flexDirection: 'column', gap: 7, alignItems: 'center',
                  }}>
                    {[
                      { k: 'like',  el: <IHeart size={13} color="#FF3B5C"/>, n: r.likes,    pop: true },
                      { k: 'cmt',   el: <IComment size={12} color="rgba(255,255,255,0.95)"/>, n: r.comments },
                      { k: 'share', el: <IShare size={12} color="rgba(255,255,255,0.95)"/>,   n: r.shares },
                    ].map((act) => (
                      <div key={act.k} style={{
                        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
                      }}>
                        <span style={Object.assign({
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.7))',
                        }, act.pop && idx === i ? { animation: 'seLike 0.75s cubic-bezier(0.16,1,0.3,1) 0.25s both' } : {})}>
                          {act.el}
                        </span>
                        <span style={{
                          fontSize: 6, fontWeight: 800, letterSpacing: '-0.01em',
                          color: 'rgba(255,255,255,0.92)',
                          textShadow: '0 1px 3px rgba(0,0,0,0.8)',
                        }}>{act.n}</span>
                      </div>
                    ))}
                  </div>
                  {/* creator row */}
                  <div style={{ position: 'absolute', left: 6, right: 6, bottom: 7 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4 }}>
                      <img src={r.pfp} alt="" style={{
                        width: 14, height: 14, borderRadius: '50%', objectFit: 'cover',
                        border: '1px solid rgba(255,255,255,0.5)',
                      }}/>
                      <span style={{ fontSize: 7.5, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>{r.handle}</span>
                    </div>
                    <div style={{ height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.30)', width: '78%', marginBottom: 3 }}/>
                    <div style={{ height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.18)', width: '52%' }}/>
                  </div>
                  {/* the credit stamped on the reel as it is scrolled past */}
                  {idx === i && (
                    <div key={'s' + idx} style={{
                      position: 'absolute', top: 62, left: 4, right: 28, zIndex: 4,
                      display: 'flex', justifyContent: 'center',
                      pointerEvents: 'none',
                    }}>
                      <span style={{
                        padding: '4px 8px', borderRadius: 99,
                        background: 'rgba(6,19,32,0.72)', backdropFilter: 'blur(6px)',
                        WebkitBackdropFilter: 'blur(6px)',
                        border: '1px solid rgba(84,216,252,0.55)',
                        fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 11.5, color: '#54D8FC',
                        textShadow: '0 0 10px rgba(84,216,252,0.8)', whiteSpace: 'nowrap',
                        animation: 'seStamp 1.5s ease-out both',
                      }}>+${SE_RATE.toFixed(2)}</span>
                    </div>
                  )}
                </div>
              );
            })}

            {/* thumb swipe hint */}
            <div aria-hidden="true" style={{
              position: 'absolute', right: 13, bottom: 16, zIndex: 5,
              width: 15, height: 22, borderRadius: 99,
              background: 'linear-gradient(180deg, rgba(255,255,255,0.85), rgba(255,255,255,0.25))',
              boxShadow: '0 0 12px rgba(255,255,255,0.5)',
              animation: 'seThumb 1.55s ease-in-out infinite',
              pointerEvents: 'none',
            }}/>

            {/* screen glass */}
            <div style={{
              position: 'absolute', inset: 0, pointerEvents: 'none',
              background: 'linear-gradient(200deg, rgba(255,255,255,0.13) 0%, transparent 38%)',
            }}/>
          </div>
        </div>

        {/* copy */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 17, lineHeight: 1.32,
            letterSpacing: '-0.03em', marginBottom: 6,
          }}>
            <span style={{
              background: 'linear-gradient(100deg, #FFFFFF 0%, #CFF3FF 40%, #FFFFFF 70%, #FFFFFF 100%)',
              backgroundSize: '200% 100%',
              WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent',
              animation: 'seGlint 4.5s linear infinite',
            }}>Every scroll pays to</span>{' '}<ApplePayMark size={20}/>
          </div>

          <p style={{
            margin: 0, fontSize: 11, lineHeight: 1.42, color: 'rgba(255,255,255,0.62)',
            letterSpacing: '-0.005em',
          }}>
            Swipe sponsored reels like you already do. Each one credits
            <span style={{ color: '#BAE6FD', fontWeight: 800 }}> ${SE_RATE.toFixed(2)}</span> straight
            to your Apple Pay.
          </p>
        </div>
      </div>
    </div>
  );
}

// ----- STICKY APPLE WALLET CTA -----
function StickyCta({ a, b }) {
  return (
    <div style={{
      position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 900,
      display: 'flex', justifyContent: 'center',
      padding: '11px 13px calc(9px + env(safe-area-inset-bottom))',
      background: 'linear-gradient(180deg, rgba(3,9,15,0) 0%, rgba(3,9,15,0.86) 34%, rgba(3,9,15,0.97) 100%)',
      backdropFilter: 'blur(18px) saturate(1.2)', WebkitBackdropFilter: 'blur(18px) saturate(1.2)',
      animation: 'scBarIn 0.5s cubic-bezier(0.16,1,0.3,1) both',
    }}>
      {/* glowing hairline along the top edge */}
      <div aria-hidden="true" style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 1,
        background: `linear-gradient(90deg, transparent, color-mix(in oklch, ${accent(a)} 70%, transparent) 25%, color-mix(in oklch, ${accent(b)} 70%, transparent) 75%, transparent)`,
        opacity: 0.75,
      }}/>

      <div style={{ width: '100%', maxWidth: 440 }}>

        {/* ── WALLET PASS LISTING ROW ── */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 11, marginBottom: 10,
        }}>
          {/* app icon */}
          <div style={{ position: 'relative', flexShrink: 0 }}>
            <img src="gravypass-logo.png" width={46} height={46} alt="GravyPass"
              style={{
                display: 'block', borderRadius: 11,
                boxShadow: `0 5px 16px rgba(0,0,0,0.55), 0 0 22px color-mix(in oklch, ${accent(a)} 26%, transparent), inset 0 0 0 1px rgba(255,255,255,0.14)`,
              }}/>
            {/* app-store style checkmark */}
            <span style={{
              position: 'absolute', right: -3, bottom: -3,
              width: 16, height: 16, borderRadius: '50%',
              background: `linear-gradient(140deg, ${accent(a)}, ${accent(b)})`,
              border: '2px solid #060F18',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <ICheck size={8} color="#042033"/>
            </span>
          </div>

          {/* name + rating + chart rank */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2,
            }}>
              <span style={{
                fontFamily: '"Poppins", -apple-system, sans-serif', fontWeight: 700,
                fontSize: 15, letterSpacing: '-0.02em', color: '#fff', lineHeight: 1.1,
              }}>gravypass</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 3,
                padding: '2px 6px', borderRadius: 5,
                background: 'rgba(255,255,255,0.09)',
                border: '1px solid rgba(255,255,255,0.10)',
                fontSize: 8, fontWeight: 700, letterSpacing: '0.02em',
                color: 'rgba(255,255,255,0.72)',
              }}>
                <IWallet size={8} color="rgba(255,255,255,0.85)"/>
                Apple Wallet
              </span>
            </div>

            {/* stars + rating */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 3 }}>
              <span style={{ display: 'flex', gap: 0.5 }}>
                {[0,1,2,3,4].map((k) => <IStar key={k} size={9.5} fill="#FFC65C"/>)}
              </span>
              <span style={{ fontSize: 10.5, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>4.7</span>
              <span style={{ fontSize: 9.5, fontWeight: 600, color: 'rgba(255,255,255,0.45)' }}>264K ratings</span>
            </div>

            {/* chart ranking */}
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 4,
              padding: '2.5px 7px', borderRadius: 99,
              background: 'linear-gradient(120deg, rgba(255,198,92,0.20), rgba(255,198,92,0.07))',
              border: '1px solid rgba(255,198,92,0.34)',
            }}>
              <IChart size={8.5} color="#FFC65C"/>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '0.01em', color: '#FFD98F' }}>
                #12 in Finance
              </span>
            </div>
          </div>
        </div>

        {/* ── ADD TO APPLE WALLET ── */}
        <button onClick={() => goToOffer()} style={{
          position: 'relative', overflow: 'hidden',
          width: '100%', border: 'none', cursor: 'pointer',
          padding: '14px 18px', borderRadius: 99,
          background: `linear-gradient(100deg, ${accent(a)} 0%, ${accent(b)} 100%)`,
          color: '#042033',
          fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 16.5, letterSpacing: '-0.02em',
          boxShadow: `0 7px 26px color-mix(in oklch, ${accent(a)} 46%, transparent), inset 0 1px 0 rgba(255,255,255,0.5)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span aria-hidden="true" style={{
            position: 'absolute', top: 0, bottom: 0, width: '38%',
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.52), transparent)',
            animation: 'scSheen 3.2s ease-in-out infinite',
            pointerEvents: 'none',
          }}/>
          <span style={{ position: 'relative', zIndex: 2, display: 'flex', alignItems: 'center', gap: 8 }}>
            <IWallet size={16} color="#042033"/>
            ADD TO APPLE WALLET
          </span>
        </button>

        <div style={{
          textAlign: 'center', marginTop: 6,
          fontSize: 9, fontWeight: 700, letterSpacing: '0.03em',
          color: 'rgba(255,255,255,0.40)',
        }}>
          FREE · ADDS TO WALLET IN 30 SECONDS · 18+
        </div>
      </div>
    </div>
  );
}

function NeonButton({ children, onClick, a, b }) {
  const [press, setPress] = React.useState(false);
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      onMouseLeave={() => setPress(false)}
      style={{
        '--na': accent(a), '--nb': accent(b),
        position: 'relative', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        width: '100%', padding: '17px 18px',
        background: 'transparent',
        color: '#042033',
        border: 'none', borderRadius: 16,
        fontFamily: '"Inter Tight"', fontWeight: 900, fontSize: 15.5, letterSpacing: '0.03em',
        cursor: 'pointer',
        transform: press ? 'scale(0.985)' : 'scale(1)',
        transition: 'transform 0.12s ease',
        boxShadow: '0 12px 30px -8px color-mix(in oklch, var(--na) 60%, transparent), 0 2px 6px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.5)',
      }}>
      <span style={{ position: 'relative', zIndex: 2, textShadow: '0 1px 0 rgba(255,255,255,0.28)' }}>{children}</span>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, #54D8FC 0%, #38BDF8 52%, #1E9FE0 100%)',
        zIndex: 0,
      }}/>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0.06) 42%, transparent 60%)',
        zIndex: 1, pointerEvents: 'none',
      }}/>
      <div style={{
        position: 'absolute', top: 0, bottom: 0, left: '-45%', width: '40%',
        background: 'linear-gradient(105deg, transparent, rgba(255,255,255,0.55), transparent)',
        transform: 'skewX(-18deg)', zIndex: 1, pointerEvents: 'none',
        animation: 'btnSheen 5s ease-in-out infinite',
      }}/>
    </button>
  );
}

// ───────── INLINE SPIN WHEEL — gold $150, fancy animations ─────────
function InlineSpinWheel({ tweaks, onWin }) {
  const a = tweaks.accentHueA, b = tweaks.accentHueB;
  const winAmt = tweaks.wheelWinAmount;
  const [phase, setPhase] = React.useState('idle');
  const [rotation, setRotation] = React.useState(0);
  const [showToast, setShowToast] = React.useState(false);

  // 4 wedges only — gold is the win
  const wedges = [
    { label: '$0',   fill: 'url(#wedgeGray)',   text: 'rgba(255,255,255,0.7)' },
    { label: '$25',  fill: 'url(#wedgePurple)', text: '#fff' },
    { label: '$75',  fill: 'url(#wedgePink)',   text: '#fff' },
    { label: `$${winAmt}`, fill: 'url(#wedgeGold)',   text: '#3D2B00', big: true, gold: true },
  ];
  const N = wedges.length;
  const slice = 360 / N;
  const winIdx = 3; // $150

  const spin = () => {
    if (phase !== 'idle') return;
    const target = -(winIdx * slice + slice / 2);
    const turns = 10;
    const final = turns * 360 + target;
    setRotation(final);
    setPhase('spinning');
    setTimeout(() => {
      setPhase('won');
      if (onWin) onWin();
      setTimeout(() => setShowToast(true), 350);
    }, 6800);
  };

  const size = 220;
  const r = size / 2;
  const cx = r, cy = r;

  return (
    <div style={{
      marginTop: 18,
      position: 'relative', overflow: 'hidden',
      background: 'radial-gradient(ellipse at top, #2A1A05 0%, #14090B 55%, #050203 100%)',
      border: '1px solid rgba(255,217,118,0.45)',
      borderRadius: 20, padding: '14px 12px 14px',
      boxShadow: '0 24px 60px -18px rgba(255,179,71,0.45), inset 0 1px 0 rgba(255,217,118,0.25), inset 0 0 60px rgba(255,179,71,0.06)',
    }}>
      {/* Subtle gold edge sheen */}
      <div style={{
        position: 'absolute', inset: 0, borderRadius: 20, pointerEvents: 'none',
        background: 'linear-gradient(135deg, rgba(255,244,194,0.08) 0%, transparent 35%, transparent 65%, rgba(255,179,71,0.06) 100%)',
        zIndex: 0,
      }}/>
      {/* Aura */}
      <div style={{ position: 'absolute', top: -50, left: '50%', transform: 'translateX(-50%)',
        width: 380, height: 380, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(255,217,118,0.28) 0%, rgba(255,179,71,0.08) 40%, transparent 65%)',
        pointerEvents: 'none', zIndex: 0,
        animation: 'wheelAura 4s ease-in-out infinite',
      }}/>

      {/* Header */}
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4, gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 20, lineHeight: 1.1, letterSpacing: '-0.025em', color: '#FFE49A' }}>
            One free spin
          </div>
        </div>
      </div>
      {false && (
      <div style={{
        fontSize: 9, letterSpacing: '0.14em', fontWeight: 800,
          color: '#FCA5A5',
          background: 'rgba(239,68,68,0.12)',
          padding: '4px 7px', borderRadius: 99,
          border: '1px solid rgba(239,68,68,0.3)',
          flexShrink: 0, whiteSpace: 'nowrap',
        }}>1 SPIN LEFT</div>
      )}

      {/* Wheel + right column */}
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
        <div style={{ position: 'relative', width: size, height: size + 22, flexShrink: 0 }}>
          {/* Pointer */}
          <div style={{
            position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
            width: 0, height: 0,
            borderLeft: '12px solid transparent', borderRight: '12px solid transparent',
            borderTop: '22px solid #FFD976',
            filter: 'drop-shadow(0 0 10px #FFD976) drop-shadow(0 2px 0 #B8860B)',
            zIndex: 6,
          }}/>
          {/* Rotating gold ring */}
          <div style={{
            position: 'absolute', top: 16, left: 0, width: size, height: size, borderRadius: '50%',
            background: 'conic-gradient(from 0deg, #FFF4C2 0%, #FFD976 18%, #B8860B 36%, #FFE49A 54%, #FFD976 72%, #8B6508 88%, #FFF4C2 100%)',
            animation: 'wheelRingSpin 6s linear infinite',
            boxShadow: '0 0 50px rgba(255,217,118,0.5), inset 0 0 18px rgba(184,134,11,0.4)',
            pointerEvents: 'none',
            zIndex: 1,
          }}/>
          {/* Static wheel wrapper sits on top of the ring */}
          <div style={{
            position: 'absolute', top: 16, left: 0, width: size, height: size, borderRadius: '50%',
            padding: 4,
            zIndex: 2,
          }}>
            <div style={{ width: '100%', height: '100%', borderRadius: '50%', background: 'radial-gradient(circle at 50% 50%, #1A0F03 0%, #0A0502 70%, #050201 100%)', padding: 4, boxShadow: 'inset 0 0 24px rgba(0,0,0,0.8), inset 0 2px 4px rgba(255,217,118,0.15)' }}>
              <svg width={size - 16} height={size - 16} viewBox={`0 0 ${size} ${size}`}
                style={{
                  transform: `rotate(${rotation}deg)`,
                  transition: phase === 'spinning' ? 'transform 6.8s cubic-bezier(.08,.78,.16,1)' : 'none',
                  borderRadius: '50%', display: 'block',
                }}>
                <defs>
                  <radialGradient id="wedgeGold" cx="50%" cy="50%" r="60%">
                    <stop offset="0%" stopColor="#FFF4C2"/>
                    <stop offset="40%" stopColor="#FFD976"/>
                    <stop offset="100%" stopColor="#B8860B"/>
                  </radialGradient>
                  <radialGradient id="wedgePurple" cx="50%" cy="50%" r="70%">
                    <stop offset="0%" stopColor="#5A3410"/>
                    <stop offset="100%" stopColor="#2A1605"/>
                  </radialGradient>
                  <radialGradient id="wedgePink" cx="50%" cy="50%" r="70%">
                    <stop offset="0%" stopColor="#7A4A12"/>
                    <stop offset="100%" stopColor="#3D2208"/>
                  </radialGradient>
                  <radialGradient id="wedgeGray" cx="50%" cy="50%" r="70%">
                    <stop offset="0%" stopColor="#3A2A14"/>
                    <stop offset="100%" stopColor="#1A0F05"/>
                  </radialGradient>
                </defs>
                {wedges.map((w, i) => {
                  const a1 = (i * slice - 90) * Math.PI / 180;
                  const a2 = ((i + 1) * slice - 90) * Math.PI / 180;
                  const x1 = cx + r * Math.cos(a1);
                  const y1 = cy + r * Math.sin(a1);
                  const x2 = cx + r * Math.cos(a2);
                  const y2 = cy + r * Math.sin(a2);
                  const path = `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 0 1 ${x2} ${y2} Z`;
                  const aMid = ((i + 0.5) * slice - 90) * Math.PI / 180;
                  const lr = r * 0.66;
                  const lx = cx + lr * Math.cos(aMid);
                  const ly = cy + lr * Math.sin(aMid);
                  const labelRot = (i + 0.5) * slice;
                  return (
                    <g key={i}>
                      <path d={path} fill={w.fill} stroke="#3A2410" strokeWidth="1.5"/>
                      {w.gold && (
                        <path d={path} fill="url(#wedgeGold)" opacity="0.6"
                          style={{ filter: 'blur(2px)', mixBlendMode: 'screen' }}/>
                      )}
                      <text x={lx} y={ly} fill={w.text}
                        fontFamily='"Inter Tight", -apple-system, BlinkMacSystemFont, sans-serif' fontWeight={w.big ? 900 : 800}
                        fontSize={w.big ? 22 : 17}
                        textAnchor="middle" dominantBaseline="central"
                        transform={`rotate(${labelRot}, ${lx}, ${ly})`}
                        style={{ textShadow: w.gold ? '0 1px 0 rgba(255,255,255,0.45), 0 0 10px rgba(255,179,71,0.5)' : '0 1px 2px rgba(0,0,0,0.7)' }}>
                        {w.label}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>
          {/* Slow shine sweep across the wheel */}
          <div style={{
            position: 'absolute', top: 16, left: 0, width: size, height: size, borderRadius: '50%',
            background: 'conic-gradient(from 0deg, transparent 0%, transparent 35%, rgba(255,244,194,0.18) 50%, transparent 65%, transparent 100%)',
            mixBlendMode: 'screen',
            pointerEvents: 'none',
            zIndex: 3,
            animation: 'wheelShine 5.5s linear infinite',
          }}/>
          {/* Center hub */}
          <div style={{
            position: 'absolute', top: 16 + r - 26, left: r - 26, width: 52, height: 52,
            borderRadius: '50%',
            background: 'radial-gradient(circle at 32% 28%, #FFFBE0 0%, #FFE49A 28%, #FFD976 50%, #C99613 80%, #6B4505 100%)',
            border: '2px solid #FFD976',
            outline: '3px solid #1A0F03',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 32px rgba(255,217,118,0.85), inset 0 -4px 8px rgba(91,50,5,0.6), inset 0 3px 5px rgba(255,255,255,0.55)',
            zIndex: 4, pointerEvents: 'none',
          }}>
            <span style={{ fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 12, color: '#3D2B00', letterSpacing: '0.06em', textShadow: '0 1px 0 rgba(255,255,255,0.5)' }}>SPIN</span>
          </div>
          {/* Sparkles on win */}
          {phase === 'won' && [...Array(16)].map((_, i) => (
            <span key={i} style={{
              position: 'absolute', top: 16 + r, left: r,
              width: i % 3 === 0 ? 8 : 6, height: i % 3 === 0 ? 8 : 6, borderRadius: '50%',
              background: i % 2 ? '#FFD976' : '#FFF4C2',
              boxShadow: '0 0 12px #FFD976, 0 0 4px #FFF4C2',
              animation: `wheelSparkle 1.4s ease-out ${i * 0.04}s forwards`,
              transform: `rotate(${i * (360/16)}deg) translateY(-${r}px)`,
              transformOrigin: 'center',
              pointerEvents: 'none',
            }}/>
          ))}
        </div>

        {/* Right column */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {phase === 'idle' && (
            <>
              <div style={{
                fontSize: 12.5, fontWeight: 600, lineHeight: 1.4, marginBottom: 10,
                color: '#FFF1C7',
                textShadow: '0 0 10px rgba(255,217,118,0.25)',
              }}>
                Whatever you land on is yours, credited the moment the pass hits your wallet.
              </div>
              <button onClick={spin} style={{
                width: '100%', padding: '13px 12px',
                background: 'linear-gradient(90deg, #FFE49A 0%, #FFD976 22%, #FFB347 50%, #FFD976 78%, #FFE49A 100%)',
                backgroundSize: '200% 100%',
                color: '#3D2B00', border: '1px solid rgba(255,244,194,0.6)', borderRadius: 12,
                fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 13.5, letterSpacing: '0.04em',
                cursor: 'pointer',
                boxShadow: '0 8px 24px rgba(255,179,71,0.45), inset 0 1px 0 rgba(255,255,255,0.55), inset 0 -2px 4px rgba(91,50,5,0.3)',
                animation: 'goldShimmer 3.2s linear infinite, wheelCtaPulse 1.8s ease-in-out infinite',
                textShadow: '0 1px 0 rgba(255,255,255,0.4)',
              }}>
                🎰 SPIN NOW
              </button>
            </>
          )}
          {phase === 'spinning' && (
            <div style={{ fontSize: 12.5, color: 'rgba(255,217,118,0.85)', textAlign: 'center', padding: '20px 0', fontWeight: 700, letterSpacing: '0.08em' }}>
              SPINNING<span style={{ animation: 'wheelDots 1s steps(4) infinite' }}>…</span>
            </div>
          )}
          {phase === 'won' && (
            <div style={{ animation: 'wheelWin 0.5s cubic-bezier(.18,.89,.32,1.28)' }}>
              <div style={{
                fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 26, lineHeight: 1,
                background: 'linear-gradient(90deg, #FFF4C2, #FFD976, #FFB347)',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                letterSpacing: '-0.03em', marginBottom: 2,
                filter: 'drop-shadow(0 0 12px rgba(255,217,118,0.5))',
              }}>You won ${winAmt}!</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 8 }}>
                Locked in. Add to Wallet to claim.
              </div>
              <button onClick={() => goToOffer()} style={{
                width: '100%', padding: '13px 12px',
                background: 'linear-gradient(90deg, #FFE49A 0%, #FFD976 22%, #FFB347 50%, #FFD976 78%, #FFE49A 100%)',
                backgroundSize: '200% 100%',
                color: '#3D2B00', border: '1px solid rgba(255,244,194,0.65)', borderRadius: 12,
                fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 12.5, letterSpacing: '0.04em',
                cursor: 'pointer',
                boxShadow: '0 8px 28px rgba(255,179,71,0.55), inset 0 1px 0 rgba(255,255,255,0.55), inset 0 -2px 4px rgba(91,50,5,0.3)',
                animation: 'goldShimmer 2.4s linear infinite',
                textShadow: '0 1px 0 rgba(255,255,255,0.4)',
              }}>
                ⚡ CLAIM ${winAmt}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post-spin notification toast */}
      {showToast && (
        <div style={{
          position: 'fixed', bottom: 14, left: 12, right: 12, zIndex: 9999,
          background: 'rgba(20,12,40,0.95)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          border: '1px solid rgba(255,217,118,0.4)',
          borderRadius: 14,
          padding: '10px 12px',
          display: 'flex', alignItems: 'center', gap: 10,
          boxShadow: '0 16px 48px rgba(0,0,0,0.6), 0 0 24px rgba(255,217,118,0.25)',
          animation: 'toastSlide 0.4s cubic-bezier(.18,.89,.32,1.28)',
          fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 9,
            background: 'linear-gradient(135deg, #FFD976, #FFB347)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, flexShrink: 0,
            boxShadow: '0 4px 12px rgba(255,179,71,0.5)',
          }}>🎉</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, fontWeight: 800, color: '#fff', lineHeight: 1.2, marginBottom: 1 }}>
              ${winAmt} unlocked. Add to Wallet to claim
            </div>
            <div style={{ fontSize: 10.5, color: 'rgba(255,255,255,0.6)', lineHeight: 1.2 }}>
              Tap to add · Bonus expires in 9:58
            </div>
          </div>
          <button onClick={() => goToOffer()} style={{
            background: 'linear-gradient(90deg, #FFD976, #FFB347)',
            color: '#3D2B00', border: 'none',
            padding: '7px 11px', borderRadius: 9,
            fontFamily: '"Inter Tight", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', fontWeight: 900, fontSize: 11, letterSpacing: '0.04em',
            cursor: 'pointer', flexShrink: 0,
            boxShadow: '0 4px 12px rgba(255,179,71,0.5)',
          }}>OPEN</button>
          <button onClick={() => setShowToast(false)} style={{
            background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.4)',
            fontSize: 16, cursor: 'pointer', padding: 0, width: 18, height: 18, lineHeight: 1, flexShrink: 0,
          }}>×</button>
        </div>
      )}

      
    </div>
  );
}

// ───────── TWEAKS ─────────
function TweaksPanel({ tweaks, update, onStageReset }) {
  const Row = ({ label, children }) => (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 10, letterSpacing: '0.1em', color: 'rgba(255,255,255,0.55)', fontWeight: 700, marginBottom: 4, textTransform: 'uppercase' }}>{label}</div>
      {children}
    </div>
  );
  const input = {
    width: '100%', padding: '6px 8px', fontSize: 12,
    background: 'rgba(255,255,255,0.06)', color: '#fff',
    border: '1px solid rgba(255,255,255,0.1)', borderRadius: 6,
    fontFamily: 'inherit',
  };
  const toggle = (k) => (
    <button onClick={() => update(k, !tweaks[k])} style={{
      padding: '6px 10px', fontSize: 11, borderRadius: 6,
      border: '1px solid rgba(255,255,255,0.12)',
      background: tweaks[k] ? accent(tweaks.accentHueA) : 'rgba(255,255,255,0.05)',
      color: tweaks[k] ? '#061320' : '#fff', fontWeight: 700, cursor: 'pointer',
    }}>{tweaks[k] ? 'ON' : 'OFF'}</button>
  );
  return (
    <div style={{
      position: 'fixed', bottom: 16, right: 16, width: 300,
      background: '#16110A', color: '#fff',
      border: '1px solid rgba(255,255,255,0.15)',
      borderRadius: 14, padding: 16,
      fontSize: 12, zIndex: 10000,
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      maxHeight: '80vh', overflowY: 'auto',
    }}>
      <div style={{ fontFamily: '"Inter Tight"', fontWeight: 800, fontSize: 14, marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        Tweaks
        <span style={{ fontSize: 9, color: accentSoft(tweaks.accentHueA), fontWeight: 600 }}>● LIVE</span>
      </div>

      <Row label="Headline line 1">
        <input style={input} value={tweaks.headlineLine1} onChange={e => update('headlineLine1', e.target.value)}/>
      </Row>
      <Row label="Headline line 2 (gradient)">
        <input style={input} value={tweaks.headlineLine2} onChange={e => update('headlineLine2', e.target.value)}/>
      </Row>
      <Row label="Subheadline">
        <textarea style={{ ...input, minHeight: 48, resize: 'vertical' }} value={tweaks.subheadline} onChange={e => update('subheadline', e.target.value)}/>
      </Row>
      <Row label="Primary CTA">
        <input style={input} value={tweaks.primaryCta} onChange={e => update('primaryCta', e.target.value)}/>
      </Row>
      <Row label={`Bonus amount: $${tweaks.bonusAmount}`}>
        <input type="range" min="5" max="100" step="5" value={tweaks.bonusAmount}
          onChange={e => update('bonusAmount', +e.target.value)} style={{ width: '100%' }}/>
      </Row>
      <Row label={`Accent A (hue: ${tweaks.accentHueA})`}>
        <input type="range" min="0" max="360" value={tweaks.accentHueA}
          onChange={e => update('accentHueA', +e.target.value)} style={{ width: '100%' }}/>
      </Row>
      <Row label={`Accent B (hue: ${tweaks.accentHueB})`}>
        <input type="range" min="0" max="360" value={tweaks.accentHueB}
          onChange={e => update('accentHueB', +e.target.value)} style={{ width: '100%' }}/>
      </Row>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
        <Row label="Skip gate">{toggle('skipAgeGate')}</Row>
        <Row label="Urgency">{toggle('urgencyBanner')}</Row>
        <Row label="Offers">{toggle('showOfferGrid')}</Row>
        <Row label="Payouts">{toggle('showPayoutProof')}</Row>
      </div>
      <button onClick={onStageReset} style={{
        width: '100%', padding: '8px', fontSize: 11, fontWeight: 700,
        background: 'rgba(255,255,255,0.08)', color: '#fff',
        border: '1px solid rgba(255,255,255,0.15)', borderRadius: 6, cursor: 'pointer',
      }}>↻ Reset to entry</button>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
