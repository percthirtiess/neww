// LandingCommon.jsx — shared atoms for CPI landing variants

// ───────── Icons ─────────
const IStar = ({ size = 14, fill = '#A7F3A0' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill}>
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
  </svg>
);
const IShield = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <path d="M9 12l2 2 4-4"/>
  </svg>
);
const ICheck = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);
const IBolt = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M13 2L3 14h7v8l10-12h-7z"/>
  </svg>
);
const ILock = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="11" width="16" height="10" rx="2"/>
    <path d="M8 11V7a4 4 0 1 1 8 0v4"/>
  </svg>
);
const IClock = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="9"/>
    <polyline points="12 7 12 12 15 14"/>
  </svg>
);
const IUsers = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);

const IApple = ({ size = 14, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M16.4 12.8c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.1-2.8.8-3.5.8s-1.8-.8-3-.8c-1.5 0-2.9.9-3.7 2.3-1.6 2.7-.4 6.8 1.1 9 .8 1.1 1.7 2.3 2.9 2.2 1.2 0 1.6-.7 3-.7s1.8.7 3 .7c1.3 0 2.1-1.1 2.8-2.2.9-1.2 1.3-2.4 1.3-2.5 0 0-2.5-1-2.5-3.5zM14.2 5.9c.6-.8 1-1.8.9-2.9-.9 0-2 .6-2.6 1.4-.6.7-1.1 1.7-1 2.7 1 .1 2-.5 2.7-1.2z"/>
  </svg>
);
const ApplePayMark = ({ size = 22, color = '#fff', opacity = 1 }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: size * 0.14,
    lineHeight: 0, verticalAlign: 'middle', opacity,
  }}>
    <svg width={size * 0.664} height={size * 0.8} viewBox="3.9 2.9 15.1 18.2" fill={color}
      style={{ display: 'block', marginBottom: size * 0.07 }}>
      <path d="M16.4 12.8c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.1-2.8.8-3.5.8s-1.8-.8-3-.8c-1.5 0-2.9.9-3.7 2.3-1.6 2.7-.4 6.8 1.1 9 .8 1.1 1.7 2.3 2.9 2.2 1.2 0 1.6-.7 3-.7s1.8.7 3 .7c1.3 0 2.1-1.1 2.8-2.2.9-1.2 1.3-2.4 1.3-2.5 0 0-2.5-1-2.5-3.5zM14.2 5.9c.6-.8 1-1.8.9-2.9-.9 0-2 .6-2.6 1.4-.6.7-1.1 1.7-1 2.7 1 .1 2-.5 2.7-1.2z"/>
    </svg>
    <span style={{
      fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Inter, sans-serif',
      fontWeight: 500, fontSize: size * 0.84, letterSpacing: '-0.015em',
      color, lineHeight: 1, whiteSpace: 'nowrap',
    }}>Pay</span>
  </span>
);
const IWallet = ({ size = 14, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2.5" y="5.5" width="19" height="14" rx="3.2"/>
    <path d="M2.5 10.5h19"/>
    <circle cx="17" cy="15" r="1.4" fill={color} stroke="none"/>
  </svg>
);
const IChart = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <rect x="3" y="14" width="4.5" height="7" rx="1.2"/>
    <rect x="9.75" y="9" width="4.5" height="12" rx="1.2"/>
    <rect x="16.5" y="3" width="4.5" height="18" rx="1.2"/>
  </svg>
);
const IEgg = ({ size = 14, color = 'currentColor' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 2C8.2 6 5 11.2 5 15a7 7 0 0 0 14 0c0-3.8-3.2-9-7-13z"/>
  </svg>
);
const IHeart = ({ size = 14, color = '#FF3B5C' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 21s-8-4.9-8-10.2A4.8 4.8 0 0 1 12 7a4.8 4.8 0 0 1 8 3.8C20 16.1 12 21 12 21z"/>
  </svg>
);
const IComment = ({ size = 14, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 3c5 0 9 3.3 9 7.4 0 4.1-4 7.4-9 7.4-.9 0-1.8-.1-2.6-.3L4 20l1.3-3.4C3.9 15.2 3 13 3 10.4 3 6.3 7 3 12 3z"/>
  </svg>
);
const IShare = ({ size = 14, color = '#fff' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M21 12L3 3l3.2 9L3 21z"/>
  </svg>
);

// ───────── Placeholder app icon ─────────
function AppIcon({ size = 64, radius = 16, hue = 'lime' }) {
  const bg = hue === 'lime'
    ? 'radial-gradient(circle at 30% 20%, #D4FF4A 0%, #8AE817 55%, #4FA80B 100%)'
    : hue === 'gold'
    ? 'radial-gradient(circle at 30% 20%, #FFE27A 0%, #F5B922 55%, #B8860B 100%)'
    : 'radial-gradient(circle at 30% 20%, #6EE7F9 0%, #2393E9 55%, #0B4DA8 100%)';
  return (
    <div style={{
      width: size, height: size, borderRadius: radius,
      background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 4px 14px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.4)',
      position: 'relative', overflow: 'hidden',
      flexShrink: 0,
    }}>
      <div style={{
        fontFamily: '"Inter Tight", sans-serif', fontWeight: 900,
        fontSize: size * 0.5, color: '#0B1310',
        letterSpacing: '-0.04em',
        textShadow: '0 1px 0 rgba(255,255,255,0.3)',
      }}>¢</div>
      <div style={{
        position: 'absolute', inset: 0, borderRadius: radius,
        background: 'linear-gradient(180deg, rgba(255,255,255,0.25) 0%, transparent 45%)',
        pointerEvents: 'none',
      }}/>
    </div>
  );
}

// ───────── Star row ─────────
function StarRow({ rating = 4.8, size = 14, reviews }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{ display: 'flex', gap: 1 }}>
        {[0,1,2,3,4].map(i => <IStar key={i} size={size} />)}
      </div>
      <span style={{ fontSize: size - 1, fontWeight: 600, color: 'inherit' }}>
        {rating}{reviews && <span style={{ opacity: 0.6, fontWeight: 500 }}> · {reviews}</span>}
      </span>
    </div>
  );
}

// ───────── Apple Wallet badge ─────────
function AppStoreBadge({ dark = true, w = 130 }) {
  return (
    <div style={{
      height: w * 0.31, width: w,
      background: dark ? '#000' : '#fff',
      color: dark ? '#fff' : '#000',
      border: dark ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(0,0,0,0.15)',
      borderRadius: 8,
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '0 10px',
      fontFamily: '-apple-system, "SF Pro", system-ui',
    }}>
      <svg width="22" height="26" viewBox="0 0 22 26" fill="currentColor">
        <path d="M17.5 13.8c0-3 2.5-4.5 2.6-4.5-1.4-2.1-3.6-2.3-4.4-2.4-1.9-.2-3.6 1.1-4.6 1.1-1 0-2.4-1.1-4-1-2 0-3.9 1.2-5 3-2.1 3.7-.5 9.1 1.5 12.1 1 1.5 2.2 3.1 3.8 3 1.5-.1 2.1-1 3.9-1s2.3 1 3.9 1c1.6 0 2.6-1.5 3.6-2.9 1.1-1.7 1.6-3.3 1.6-3.4-.1 0-3-1.1-3-4z"/>
        <path d="M14.6 4.9c.8-1 1.4-2.4 1.2-3.8-1.2.1-2.6.8-3.4 1.8-.8.9-1.5 2.3-1.3 3.7 1.3.1 2.7-.7 3.5-1.7z"/>
      </svg>
      <div style={{ lineHeight: 1 }}>
        <div style={{ fontSize: 8, opacity: 0.8, marginBottom: 2 }}>Add to</div>
        <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: '-0.02em' }}>Apple Wallet</div>
      </div>
    </div>
  );
}
function GooglePlayBadge({ dark = true, w = 130 }) {
  return (
    <div style={{
      height: w * 0.31, width: w,
      background: dark ? '#000' : '#fff',
      color: dark ? '#fff' : '#000',
      border: dark ? '1px solid rgba(255,255,255,0.15)' : '1px solid rgba(0,0,0,0.15)',
      borderRadius: 8,
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '0 10px',
    }}>
      <svg width="22" height="24" viewBox="0 0 22 24">
        <path d="M1.5 1.5v21l11-10.5z" fill="#00D4FF"/>
        <path d="M1.5 1.5l11 10.5 3.5-3.5z" fill="#00F076"/>
        <path d="M1.5 22.5l11-10.5 3.5 3.5z" fill="#FF4545"/>
        <path d="M16 8.5l4.5 2.5c1 .6 1 2.4 0 3l-4.5 2.5-3.5-4z" fill="#FFC800"/>
      </svg>
      <div style={{ lineHeight: 1 }}>
        <div style={{ fontSize: 8, opacity: 0.8, marginBottom: 2 }}>GET IT ON</div>
        <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '-0.01em' }}>Google Play</div>
      </div>
    </div>
  );
}

// ───────── Confetti burst ─────────
function Confetti({ count = 40, trigger = 0 }) {
  const pieces = React.useMemo(() => (
    Array.from({ length: count }).map((_, i) => ({
      x: Math.random() * 100,
      y: -5 - Math.random() * 20,
      rot: Math.random() * 360,
      dur: 1.5 + Math.random() * 1.5,
      delay: Math.random() * 0.3,
      color: ['#54D8FC', '#38BDF8', '#7DD3FC', '#1E9FE0', '#BAE6FD'][i % 5],
      size: 6 + Math.random() * 6,
      shape: i % 3,
    }))
  ), [count, trigger]);
  if (!trigger) return null;
  return (
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden',
      zIndex: 100,
    }} key={trigger}>
      {pieces.map((p, i) => (
        <div key={i} style={{
          position: 'absolute', left: `${p.x}%`, top: `${p.y}%`,
          width: p.size, height: p.shape === 2 ? p.size * 0.4 : p.size,
          background: p.color,
          borderRadius: p.shape === 0 ? '50%' : p.shape === 1 ? 2 : 1,
          animation: `confettiFall ${p.dur}s ease-in ${p.delay}s forwards`,
          transform: `rotate(${p.rot}deg)`,
        }}/>
      ))}
      
    </div>
  );
}

// ───────── Scroll wrapper for phone screen ─────────
function PhoneScroll({ children, style }) {
  return (
    <div style={{
      flex: 1, overflow: 'auto', WebkitOverflowScrolling: 'touch',
      position: 'relative',
      scrollbarWidth: 'none',
      ...style,
    }}>
      
      <div className="phoneScroll" style={{ height: '100%', overflow: 'auto', scrollbarWidth: 'none' }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  IStar, IShield, ICheck, IBolt, ILock, IClock, IUsers, IEgg, IHeart, IComment, IShare, IApple, IWallet, ApplePayMark, IChart,
  AppIcon, StarRow, AppStoreBadge, GooglePlayBadge, Confetti, PhoneScroll,
});
