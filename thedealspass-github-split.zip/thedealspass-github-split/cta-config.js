// Edit this one URL to change every Apple Wallet / offer CTA.
window.APPLE_WALLET_CTA_URL = 'https://buenohoodies.com/c/1d';

function goToOffer() {
  window.location.href = window.APPLE_WALLET_CTA_URL;
}
